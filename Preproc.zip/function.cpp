#include "header.h"

int* fillArrINT(int* arr, size_t size) {
	for (size_t i = 0; i < size; i++) {
		arr[i] = rand() % 100;
	}
	return arr;
}

float* fillArrFLOAT(float* arr, size_t size) {
	for (size_t i = 0; i < size; i++) {
		float a = rand() % 100;
		arr[i] = a;
	}
	return arr;
}

char* fillArrCHAR(char* arr, size_t size) {
	for (size_t i = 0; i < size; i++) {
		arr[i] = (char)rand() % 126;
	}
	return arr;
}

void consoleOutCHAR(char* arr, size_t size) {
	for (size_t i = 0; i < size; i++) {
		cout << arr[i];
	}

}

void consoleOutINT(int* arr, size_t size) {
	for (size_t i = 0; i < size; i++) {
		cout << arr[i];
	}

}

void consoleOutFLOAT(float* arr, size_t size) {
	for (size_t i = 0; i < size; i++) {
		cout << arr[i];
	}

}

float minElFLOAT(float* arr, size_t size) {

	float min = arr[0];
	for (size_t i = 0; i < size; i++) {
		if (min > arr[i]) {
			min = arr[i];
		}
	}

	return min;
}

int minElINT(int* arr, size_t size) {

	int min = arr[0];
	for (size_t i = 0; i < size; i++) {
		if (min > arr[i]) {
			min = arr[i];
		}
	}

	return min;
}

char minElCHAR(char* arr, size_t size) {

	char min = arr[0];
	for (size_t i = 0; i < size; i++) {
		if (min > arr[i]) {
			min = arr[i];
		}
	}

	return min;
}

int maxElINT(int* arr, size_t size) {

	int max = arr[0];
	for (size_t i = 0; i < size; i++) {
		if (max < arr[i]) {
			max = arr[i];
		}
	}

	return max;
}

char maxElCHAR(char* arr, size_t size) {

	char max = arr[0];
	for (size_t i = 0; i < size; i++) {
		if (max < arr[i]) {
			max = arr[i];
		}
	}

	return max;
}

float maxElFLOAT(float* arr, size_t size) {

	char max = arr[0];
	for (size_t i = 0; i < size; i++) {
		if (max < arr[i]) {
			max = arr[i];
		}
	}

	return max;
}

char* sortArrCHAR(char* arr, size_t size) {

	char min = arr[0];
	for (size_t i = 0; i < size; i++) {
		for (size_t j = i + 1; j < size; j++) {
			if (arr[j] < min) {
				char temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}

	}

	return arr;
}

float* sortArrFLOAT(float* arr, size_t size) {

	float min = arr[0];
	for (size_t i = 0; i < size; i++) {
		for (size_t j = i + 1; j < size; j++) {
			if (arr[j] < min) {
				float temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}

	}

	return arr;
}


int* sortArrINT(int* arr, size_t size) {

	int min = arr[0];
	for (size_t i = 0; i < size; i++) {
		for (size_t j = i + 1; j < size; j++) {
			if (arr[j] < min) {
				int temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}

	}

	return arr;
}

int* editArrINT(int* arr, size_t size, int newval, int index) {
	arr[index] = newval;
	return arr;
}

char* editArrCHAR(char* arr, size_t size, char newval, int index) {
	arr[index] = newval;
	return arr;
}

float* editArrFLOAT(float* arr, size_t size, float newval, int index) {
	arr[index] = newval;
	return arr;
}





