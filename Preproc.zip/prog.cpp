#include "header.h"

int main() {

#define INTEGER int

	INTEGER * arr = new INTEGER[100];
	arr = FillArray(arr, 100);

#undef INTEGER

#define CHAR char
	CHAR * arr1 = new CHAR[100];
	arr1 = FillArray(arr1, 100);
#undef CHAR

#define FLOAT float

	FLOAT * arr1 = new FLOAT[100];
	arr1 = FillArray(arr1, 100);

#undef FLOAT

	

	return 0;
}