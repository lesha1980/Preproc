#pragma once

#include <iostream>
#include <ctime>

using namespace std;

#define TIMENULL time(NULL); 

#include "function.h"
