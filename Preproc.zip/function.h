#pragma once

int* fillArrINT(int*, size_t);
float* fillArrFLOAT(float*, size_t);
char* fillArrCHAR(char*, size_t);
void consoleOutCHAR(char*, size_t);
void consoleOutINT(int*, size_t);
void consoleOutFLOAT(float*, size_t);
float minElFLOAT(float*, size_t);
int minElINT(int*, size_t);
char minElCHAR(char*, size_t);
int maxElINT(int*, size_t);
char maxElCHAR(char*, size_t);
float maxElFLOAT(float*, size_t);
char* sortArrCHAR(char*, size_t);
float* sortArrFLOAT(float*, size_t);
int* sortArrINT(int*, size_t);
int* editArrINT(int*, size_t, int, int);
char* editArrCHAR(char*, size_t, char, int);
float* editArrFLOAT(float*, size_t, float, int);



#ifdef INTEGER

#define ShowArray consoleOutINT
#define FillArray fillArrINT
#define MinElementArray minElINT
#define MaxElementArray maxElINT
#define SortArray sortArrINT
#define EditElementArray editArrINT
 

#elif deined FLOAT

#define ShowArray consoleOutFLOAT
#define FillArray fillArrFLOAT
#define MinElementArray minElFLOAT
#define MaxElementArray maxElFLOAT
#define SortArray sortArrFLOAT
#define EditElementArray editArrFLOAT

#elif defined CHAR

#define ShowArray consoleOutCHAR
#define FillArray fillArrCHAR
#define MinElementArray minElCHAR
#define MaxElementArray maxElCHAR
#define SortArray sortArrCHAR
#define EditElementArray editArrCHAR

#endif 








